"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowUpRight, Mail, MapPin, Phone } from "lucide-react";
import { BrandLogo } from "@/components/BrandLogo";
import { useStore } from "@/context/StoreContext";

export function Footer() {
  const pathname = usePathname();
  const { liveSettings, openLeadModal } = useStore();

  if (pathname?.startsWith("/admin")) return null;

  const hasAnyContact = Boolean(
    liveSettings.phone ||
      liveSettings.email ||
      liveSettings.address ||
      liveSettings.workingHours ||
      liveSettings.bin
  );

  return (
    <footer className="bg-ink text-white pb-24 lg:pb-0">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Бренд */}
          <div className="space-y-4">
            <BrandLogo theme="dark" />
            <p className="text-xs leading-relaxed text-white/60 max-w-[250px]">
              Поставка спортивных покрытий, падел-кортов и света по всему Казахстану. Договор и счёт · образцы и монтаж по запросу.
            </p>
            <button
              type="button"
              onClick={() =>
                openLeadModal({
                  title: "Запросить КП",
                  source: "Подвал сайта",
                })
              }
              className="inline-flex items-center gap-1.5 rounded-full bg-track px-5 py-2.5 text-xs font-extrabold text-white hover:bg-[#e54d2b] transition-colors"
            >
              Запросить КП
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Покрытия */}
          <div>
            <h3 className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/40 mb-3.5">
              Покрытия
            </h3>
            <ul className="space-y-2 text-xs text-white/75">
              <li>
                <Link href="/catalog/sub/pvc" className="hover:text-white transition-colors">
                  Рулонный ПВХ
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/parquet" className="hover:text-white transition-colors">
                  Спортивный паркет
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/modular" className="hover:text-white transition-colors">
                  Модульные покрытия
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/track" className="hover:text-white transition-colors">
                  Беговые дорожки
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/pickleball" className="hover:text-white transition-colors">
                  Пиклбол
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/wet" className="hover:text-white transition-colors">
                  Дренажный настил
                </Link>
              </li>
            </ul>
          </div>

          {/* Падел и свет */}
          <div>
            <h3 className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/40 mb-3.5">
              Падел и свет N7
            </h3>
            <ul className="space-y-2 text-xs text-white/75">
              <li>
                <Link href="/catalog/sub/padel" className="hover:text-white transition-colors">
                  Падел-корты PD001–PD008
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/led-titan" className="hover:text-white transition-colors">
                  N7 TITAN · 250–1250 Вт
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/led-vektor" className="hover:text-white transition-colors">
                  N7 VEKTOR · 120–600 Вт
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/led-kron" className="hover:text-white transition-colors">
                  N7 KRON · 150–600 Вт
                </Link>
              </li>
              <li>
                <Link href="/catalog/sub/led-kort" className="hover:text-white transition-colors">
                  N7 KORT · 100–600 Вт
                </Link>
              </li>
            </ul>
          </div>

          {/* Навигация и живые контакты */}
          <div>
            <h3 className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/40 mb-3.5">
              Навигация
            </h3>
            <ul className="space-y-2 text-xs text-white/75">
              <li>
                <Link href="/catalog" className="hover:text-white transition-colors">
                  Каталог
                </Link>
              </li>
              <li>
                <Link href="/pricelist" className="hover:text-white transition-colors">
                  Прайс и CSV
                </Link>
              </li>
              <li>
                <Link href="/compare" className="hover:text-white transition-colors">
                  Сравнение
                </Link>
              </li>
              <li>
                <Link href="/cart" className="hover:text-white transition-colors">
                  Список КП
                </Link>
              </li>
              <li>
                <Link href="/contacts" className="hover:text-white transition-colors">
                  Контакты и заявка
                </Link>
              </li>
            </ul>

            {hasAnyContact && (
              <div className="mt-5 space-y-2 border-t border-white/10 pt-4 text-xs text-white/75">
                {liveSettings.phone && (
                  <a
                    href={`tel:+${liveSettings.phone.replace(/\D/g, "")}`}
                    className="flex items-center gap-2 font-semibold text-white hover:text-track"
                  >
                    <Phone className="h-3.5 w-3.5 text-track shrink-0" />
                    {liveSettings.phone}
                  </a>
                )}
                {liveSettings.email && (
                  <a
                    href={`mailto:${liveSettings.email}`}
                    className="flex items-center gap-2 hover:text-white"
                  >
                    <Mail className="h-3.5 w-3.5 text-track shrink-0" />
                    {liveSettings.email}
                  </a>
                )}
                {liveSettings.address && (
                  <div className="flex items-start gap-2 text-white/60">
                    <MapPin className="h-3.5 w-3.5 text-track shrink-0 mt-0.5" />
                    <span>{liveSettings.address}</span>
                  </div>
                )}
                {liveSettings.workingHours && (
                  <div className="text-[11px] text-white/50">
                    {liveSettings.workingHours}
                  </div>
                )}
                {liveSettings.bin && (
                  <div className="text-[11px] text-white/45 font-mono">
                    БИН: {liveSettings.bin}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="mt-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-t border-white/10 pt-6 text-[11px] text-white/40">
          <span>
            © {new Date().getFullYear()} N7 CONSTRUCTION · Параметры соответствуют паспортам конкретных моделей и партий.
          </span>
          <div className="flex items-center gap-4">
            <Link href="/map" className="hover:text-white/75 transition-colors">
              Карта сайта
            </Link>
            <Link href="/admin" className="hover:text-white/75 transition-colors">
              Управление
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
