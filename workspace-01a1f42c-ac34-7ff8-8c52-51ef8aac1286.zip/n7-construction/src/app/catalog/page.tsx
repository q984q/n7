import React from "react";
import { PRODUCTS } from "@/data/products";
import { buildMetadata, getItemListSchema } from "@/lib/seo";
import { JsonLd } from "@/components/JsonLd";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { CatalogBrowser } from "@/components/CatalogBrowser";
import { LeadCaptureSection } from "@/components/LeadCaptureSection";

export const metadata = buildMetadata({
  title:
    "Каталог спортивных покрытий, падел-кортов и LED-прожекторов | N7 CONSTRUCTION",
  description:
    "Каталог N7 CONSTRUCTION (67 позиций): рулонный ПВХ, спортивный паркет, модульные покрытия, беговые дорожки, падел-корты PD001–PD008 и 45 моделей прожекторов N7 TITAN, VEKTOR, KRON и KORT с доставкой по Казахстану.",
  path: "/catalog",
});

export default function CatalogPage({
  searchParams,
}: {
  searchParams?: { q?: string; sport?: string };
}) {
  const initialQuery = typeof searchParams?.q === "string" ? searchParams.q : "";
  const initialSport =
    typeof searchParams?.sport === "string" ? searchParams.sport : "all";

  return (
    <>
      <JsonLd data={getItemListSchema(PRODUCTS, "Каталог N7 CONSTRUCTION")} />

      <section className="py-10 sm:py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ name: "Каталог", path: "/catalog" }]} />

          <div className="mb-7 flex flex-wrap items-baseline gap-3">
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-[-0.03em] text-ink">
              Каталог
            </h1>
            <span className="text-sm font-semibold text-ink/45 tabular-nums">
              {PRODUCTS.length} позиций
            </span>
          </div>

          <CatalogBrowser
            initialQuery={initialQuery}
            initialSport={initialSport}
          />
        </div>
      </section>

      <LeadCaptureSection source="Страница каталога" />
    </>
  );
}
