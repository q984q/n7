import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
import { cookies } from "next/headers";
import { Product } from "@/data/products";
import { SITE_CONFIG } from "@/config/site";

export const ADMIN_COOKIE = "n7_admin_session";

const DATA_DIR = path.join(process.cwd(), "data");
const CMS_FILE = path.join(DATA_DIR, "cms.json");
const LEADS_FILE = path.join(DATA_DIR, "leads.json");

export interface ProductOverride {
  name?: string;
  price?: number;
  installPrice?: number;
  inStock?: boolean;
  stockNote?: string;
  badge?: string;
  featured?: boolean;
  hidden?: boolean;
}

export interface CmsSettings {
  phone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  workingHours: string;
  bin: string;
  iik: string;
  bank: string;
  promoBannerActive: boolean;
  promoBannerText: string;
}

export interface CmsDatabase {
  adminLogin: string;
  adminPassHash: string;
  sessionSecret: string;
  settings: CmsSettings;
  productOverrides: Record<string, ProductOverride>;
  customProducts: Product[];
}

export type LeadStatus = "new" | "in_progress" | "kp_sent" | "won" | "archived";

export interface LeadAttachment {
  fileName: string;
  storedName: string;
  size: number;
  mimeType: string;
}

export interface LeadRecord {
  ticketId: string;
  status: LeadStatus;
  managerNote: string;
  createdAt: string;
  updatedAt: string;
  name: string;
  phone: string;
  email: string;
  company: string;
  bin: string;
  city: string;
  type: string;
  source: string;
  message: string;
  contextSummary: string;
  attachment?: LeadAttachment;
  items: {
    sku: string;
    name: string;
    qty: number;
    unit: string;
    unitPrice: number;
    optionsNote?: string;
    includeInstall?: boolean;
  }[];
  totalKzt: number;
}

export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(`n7_salt::${password}`).digest("hex");
}

export function createSessionToken(login: string, secret: string): string {
  const hmac = crypto.createHmac("sha256", secret).update(login).digest("hex");
  return `${Buffer.from(login, "utf-8").toString("base64url")}.${hmac}`;
}

function getDefaultCms(): CmsDatabase {
  return {
    adminLogin: "admin",
    adminPassHash: hashPassword("n7admin2026"),
    sessionSecret: crypto.createHash("sha256").update("n7-construction-admin-session-v2").digest("hex"),
    settings: {
      phone: SITE_CONFIG.phone,
      whatsappNumber: SITE_CONFIG.whatsappNumber,
      email: SITE_CONFIG.email,
      address: SITE_CONFIG.address,
      workingHours: SITE_CONFIG.workingHours,
      bin: SITE_CONFIG.bin,
      iik: SITE_CONFIG.iik,
      bank: SITE_CONFIG.bank,
      promoBannerActive: false,
      promoBannerText: "",
    },
    productOverrides: {},
    customProducts: [],
  };
}

async function ensureDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

export async function readCms(): Promise<CmsDatabase> {
  const defaults = getDefaultCms();
  try {
    await ensureDir();
    const raw = await fs.readFile(CMS_FILE, "utf-8");
    const parsed = JSON.parse(raw) as Partial<CmsDatabase>;
    return {
      adminLogin: parsed.adminLogin || defaults.adminLogin,
      adminPassHash: parsed.adminPassHash || defaults.adminPassHash,
      sessionSecret: parsed.sessionSecret || defaults.sessionSecret,
      settings: { ...defaults.settings, ...(parsed.settings || {}) },
      productOverrides: parsed.productOverrides || {},
      customProducts: Array.isArray(parsed.customProducts) ? parsed.customProducts : [],
    };
  } catch {
    return defaults;
  }
}

export async function writeCms(db: CmsDatabase): Promise<void> {
  await ensureDir();
  await fs.writeFile(CMS_FILE, JSON.stringify(db, null, 2), "utf-8");
}

export async function isAdminAuthenticated(): Promise<boolean> {
  try {
    const store = cookies();
    const token = store.get(ADMIN_COOKIE)?.value;
    if (!token || !token.includes(".")) return false;
    const db = await readCms();
    const expected = createSessionToken(db.adminLogin, db.sessionSecret);
    return token === expected;
  } catch {
    return false;
  }
}

export function applyProductOverrides(
  baseProducts: Product[],
  overrides: Record<string, ProductOverride>,
  customProducts: Product[] = [],
  includeHidden = false
): Product[] {
  const combined = [...customProducts, ...baseProducts];
  const result: Product[] = [];

  for (const prod of combined) {
    const ov = overrides[prod.id];
    if (!includeHidden && ov?.hidden) continue;

    if (!ov) {
      result.push(prod);
      continue;
    }

    const price = typeof ov.price === "number" && ov.price >= 0 ? ov.price : prod.price;
    const installPrice =
      typeof ov.installPrice === "number" && ov.installPrice >= 0
        ? ov.installPrice
        : prod.installPrice;

    const tiers = prod.tiers.map((t, idx) => {
      if (price <= 0) {
        return { ...t, price: 0, discount: "По запросу" };
      }
      if (idx === 0) {
        return { ...t, price, discount: "Базовая цена" };
      }
      if (idx === 1) {
        return { ...t, price: Math.round(price * 0.95), discount: "-5%" };
      }
      return { ...t, price: Math.round(price * 0.9), discount: "-10%" };
    });

    result.push({
      ...prod,
      name: ov.name?.trim() ? ov.name.trim() : prod.name,
      price,
      installPrice,
      tiers,
      inStock: typeof ov.inStock === "boolean" ? ov.inStock : prod.inStock,
      stockNote: ov.stockNote !== undefined ? ov.stockNote : prod.stockNote,
      badge: ov.badge !== undefined ? ov.badge || undefined : prod.badge,
      featured: typeof ov.featured === "boolean" ? ov.featured : prod.featured,
    });
  }

  return result;
}

export async function readLeads(): Promise<LeadRecord[]> {
  try {
    await ensureDir();
    const raw = await fs.readFile(LEADS_FILE, "utf-8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function writeLeads(leads: LeadRecord[]): Promise<void> {
  await ensureDir();
  await fs.writeFile(LEADS_FILE, JSON.stringify(leads, null, 2), "utf-8");
}
